
const questions = Array.from({length: 40}, (_, i) => {
  const types = ["EI", "SN", "TF", "JP"];
  const type = types[i % 4];
  return {
    text: `問題 ${i + 1}：你更傾向？`,
    type,
    A: `${type[0]} 選項A風格`,
    B: `${type[1]} 選項B風格`
  };
});

let index = 0;
const scores = { E: 0, I: 0, S: 0, N: 0, T: 0, F: 0, J: 0, P: 0 };

function renderQuestion() {
  const q = questions[index];
  document.getElementById('question-title').textContent = q.text;
  document.querySelectorAll('.option-btn')[0].textContent = q.A;
  document.querySelectorAll('.option-btn')[1].textContent = q.B;
}

function choose(letter) {
  const dim = questions[index].type;
  scores[letter]++;
  index++;
  if (index < questions.length) {
    renderQuestion();
  } else {
    const result = 
      (scores.E >= scores.I ? 'E' : 'I') +
      (scores.S >= scores.N ? 'S' : 'N') +
      (scores.T >= scores.F ? 'T' : 'F') +
      (scores.J >= scores.P ? 'J' : 'P');
    window.location.href = `results.html?type=${result}`;
  }
}

window.onload = renderQuestion;
